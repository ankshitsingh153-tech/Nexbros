---
name: NexBros Digital System
colors:
  surface: '#faf8ff'
  surface-dim: '#dbd9e0'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#1a1b20'
  on-surface-variant: '#434655'
  inverse-surface: '#2f3035'
  inverse-on-surface: '#f2f0f7'
  outline: '#747686'
  outline-variant: '#c4c5d7'
  surface-tint: '#2f54cb'
  primary: '#00247d'
  on-primary: '#ffffff'
  primary-container: '#1d4ed8'
  on-primary-container: '#cad3ff'
  inverse-primary: '#b7c4ff'
  secondary: '#a73a00'
  on-secondary: '#ffffff'
  secondary-container: '#fd651e'
  on-secondary-container: '#571a00'
  tertiary: '#003530'
  on-tertiary: '#ffffff'
  tertiary-container: '#00685f'
  on-tertiary-container: '#7be7d9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b7c4ff'
  on-primary-fixed: '#001551'
  on-primary-fixed-variant: '#063ab2'
  secondary-fixed: '#ffdbce'
  secondary-fixed-dim: '#ffb599'
  on-secondary-fixed: '#370e00'
  on-secondary-fixed-variant: '#7f2b00'
  tertiary-fixed: '#89f5e7'
  tertiary-fixed-dim: '#6bd8cb'
  on-tertiary-fixed: '#00201d'
  on-tertiary-fixed-variant: '#045049'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#e3e1e8'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 38px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-badge:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
  space-3xl: 6rem
---

## Brand & Style

This design system expresses a high-trust, results-oriented digital partner for growing enterprises and ambitious local businesses. It blends corporate reliability with energetic commercial momentum. 

The aesthetic is grounded in **Modern Tokenized Material Design**:
- **Clarity over Clutter**: Information architecture uses clean surface elevation and clear typographic hierarchy, avoiding visual noise.
- **Vibrant Accentuation**: High-contrast, energetic accents punctuate a structured, calm chromatic base to drive key conversion paths.
- **Tactile Modernism**: Interactive controls incorporate micro-elevation shifts, atmospheric blurred gradients, and crisp low-contrast borders to convey structure and polish.
- **Approachability**: Friendly, rounded geometry pairs with authoritative, geometric grotesque typography to remain accessible without sacrificing corporate credibility.

## Colors

The color architecture is built around calibrated tonal relationships ensuring high legibility and precise focus management.

- **Primary (`#0037b0`)**: Deep cobalt blue anchoring navigation, section headlines, primary brand iconography, and structural focus rings.
- **Secondary (`#a73a00` / `#fd651e`)**: Energetic warm vermilion and terracotta. `secondary-container` (`#fd651e`) serves as the primary visual trigger for conversion events (e.g., direct booking, lead generation CTAs), while `secondary` (`#a73a00`) governs sustained hover and press actions.
- **Tertiary (`#004e47`)**: Deep mineral teal used to communicate security, validation checks, guarantee badges, and trust indicators.
- **Neutral Palette (`#faf8ff` to `#131b2e`)**: Tinted with subtle blue-violet undertones to soften pure optical contrast. Content sits on progressive container steps (`surface-container-lowest` up through `surface-container-highest`) rather than harsh absolute white or raw gray.

## Typography

The design system standardizes on **Plus Jakarta Sans** across all hierarchies to maintain a contemporary, geometric, and accessible identity.

- **Display & Large Headlines**: Set with tight negative letter tracking (`-0.02em` to `-0.03em`) and heavy weights (`700` and `800`) to create high-impact, punchy focal points in hero sections and major headers.
- **Body Text**: Tuned for high readability with balanced leading (e.g., 24px line height on 16px body) and neutral tracking.
- **Labels & Micro-copy**: Employs uppercase tracking (`+0.06em`) on small tags (`label-badge`) to maintain scanability on metrics, feature chips, and trust markers.

## Layout & Spacing

The layout model is governed by a **responsive fluid grid** contained within a central constraint:

- **Max Width**: Standardized at `80rem` (`1280px`).
- **Columns & Breakpoints**:
  - **Mobile (< 640px)**: 1-column stack with `1rem` safe margins and `1rem` gutters.
  - **Tablet (640px – 1024px)**: 2-column symmetric layout with `1.5rem` gutters.
  - **Desktop (1024px+)**: 12-column asymmetric layout (e.g., 7-column content / 5-column preview in hero scenarios) or 3-column / 4-column balanced modular grids for feature showcases.
- **Vertical Rhythm**: Section margins scale from `space-2xl` (64px) on compact screens to `space-3xl` (96px) on desktop viewports.

## Elevation & Depth

Elevation is rendered through multi-tier surface containers complemented by subtle, colored ambient shadows:

- **Resting Layer (`elevation-rest`)**: `0 1px 3px 0 rgba(15, 23, 42, 0.05), 0 1px 2px -1px rgba(15, 23, 42, 0.05)`. Used for resting cards, inputs, and floating secondary pills.
- **Interactive Layer (`elevation-interactive`)**: `0 10px 25px -5px rgba(29, 78, 216, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`. Applied to hovered cards, pricing packages, and active overlays.
- **Conversion Accent (`elevation-cta`)**: `0 8px 20px -4px rgba(234, 88, 12, 0.35)`. Tinted warm cast shadow applied exclusively to conversion CTAs to create prominent focal pull.
- **Atmospheric Depth**: Backdrop orbs using `primary-fixed` at 40% opacity paired with `blur-3xl` positioned along canvas boundaries to produce soft ambient lighting.
- **Outlines**: Structural definition avoids heavy borders, using a `1px` stroke of `outline-variant` (`#c4c5d7`). Featured states step up to a `2px` stroke of `primary`.

## Shapes

The design system applies a balanced, modern curved aesthetic:

- **Base Radius (`0.5rem` / 8px)**: Form fields, action buttons, icon wells, and nested containers.
- **Large Radius (`rounded-lg` / `0.75rem` / 12px)**: Outer boundary cards, modal containers, browser mockup windows, and pricing tier cards.
- **Pill Geometry (`rounded-full` / 9999px)**: Avatars, category badges, micro-indicators, verification tags, and conversion status markers.

## Components

### Buttons
- **Primary CTA**: Background `secondary-container`, text `on-secondary`, radius `rounded-DEFAULT` (8px), padding `12px 24px` (`space-md` horizontal). Features `elevation-cta`, lifts `-0.5px` on hover, and compresses to `scale-95` on active press. Hover switches to `secondary` (`#a73a00`).
- **Secondary / Outline**: Background `surface-container-lowest`, text `primary`, border `1px solid outline-variant`. Hover triggers `bg-surface-container-low` and border shift to `primary`.
- **Text / Link Button**: Text `primary`, font weight `600`, with icon trailing transitions shifting `+4px` on hover.

### Cards
- **Base Card**: Fill `surface-container-lowest`, border `1px solid outline-variant`, radius `rounded-xl` (12px), inner padding `space-lg` (24px).
- **Featured Card**: Border `2px solid primary`, soft fill shift to `surface-container-lowest`, applying `elevation-interactive` with a pinned top badge in `primary` or `secondary-container`.

### Chips & Badges
- **Status Badges**: Fully rounded (`rounded-full`), padding `4px 12px`, typography `label-badge`. Fill `surface-container-low`, text `primary`.
- **Trust & Verification Tags**: Fill `tertiary-fixed`, text `tertiary`, accompanied by a filled verification symbol.
- **Metric Pill**: Fill `secondary-fixed`, text `on-secondary-fixed-variant`, showing high-contrast percentage shifts.

### Form Inputs
- **Text Inputs & Textareas**: Fill `surface-container-lowest`, border `1px solid outline-variant`, radius `rounded-DEFAULT` (8px), padding `12px 16px`.
- **Focus State**: Border switches to `primary` with an outer ring of `2px solid primary/20`.
- **Labels**: Set in `label-lg`, color `on-surface-variant`, positioned above input with `space-xs` gap.

### Checkboxes & Radios
- **Control Box**: 20px box, radius 4px (checkbox) or circular (radio), border `1.5px solid outline`.
- **Selected State**: Background `primary`, border `primary`, inner check icon in `on-primary`. Focus indicates with `primary-fixed` ring.